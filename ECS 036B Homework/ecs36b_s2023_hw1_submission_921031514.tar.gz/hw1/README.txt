Name: Tyson-Tien Nguyen
Student ID: 921031514
Student Email: ttxnguyen@ucdavis.edu

MyBreak Program
    1. Breaks the desired file into a variable amount of chunks, depending on the user.

MyHeal Program
    1. Grabs all those chunks back and remake the chunked file into its original whole piece again.